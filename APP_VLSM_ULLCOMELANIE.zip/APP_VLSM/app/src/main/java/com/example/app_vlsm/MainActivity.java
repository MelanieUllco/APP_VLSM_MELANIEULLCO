package com.example.app_vlsm;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText etIpAddress, etSubnetMask, etSubnetsCount;
    private Button btnCalculate, btnShowDetails;
    private LinearLayout resultContainer;
    private TableLayout tableHostsPerSubnet, tableSubnets;
    private TextView tvSubnetsDetailTitle;
    private TextView tvEnteredDetails; // New TextView to show entered values

    // Variables para almacenar los datos entre los cálculos
    private int[] networkBaseAddress;
    private int baseCidr;
    private int[] hostsRequired;
    private String enteredIp, enteredSubnet, enteredSubnetCount; // Store entered values

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Configurar la adaptación a Edge-to-Edge
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicializar vistas
        etIpAddress = findViewById(R.id.etIpAddress);
        etSubnetMask = findViewById(R.id.etSubnetMask);
        etSubnetsCount = findViewById(R.id.etSubnetsCount);
        btnCalculate = findViewById(R.id.btnCalculate);
        btnShowDetails = findViewById(R.id.btnShowDetails);
        resultContainer = findViewById(R.id.resultContainer);
        tableHostsPerSubnet = findViewById(R.id.tableHostsPerSubnet);
        tableSubnets = findViewById(R.id.tableSubnets);
        tvSubnetsDetailTitle = findViewById(R.id.tvSubnetsDetailTitle);
        tvEnteredDetails = findViewById(R.id.tvEnteredDetails); // Initialize the new TextView

        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateVLSM();
            }
        });

        btnShowDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSubnetDetails();
            }
        });
    }


    private void calculateVLSM() {
        try {
            // Obtener valores de entrada
            enteredIp = etIpAddress.getText().toString().trim();
            enteredSubnet = etSubnetMask.getText().toString().trim();
            enteredSubnetCount = etSubnetsCount.getText().toString().trim();

            // Validar entradas
            if (enteredIp.isEmpty() || enteredSubnet.isEmpty() || enteredSubnetCount.isEmpty()) {
                Toast.makeText(this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
                return;
            }

            // Parsear la dirección IP
            int[] ipAddress = parseIpAddress(enteredIp);

            // Parsear la máscara de subred (puede estar en formato X.X.X.X o /XX)
            int cidrPrefix;
            if (enteredSubnet.contains("/")) {
                cidrPrefix = Integer.parseInt(enteredSubnet.substring(enteredSubnet.indexOf("/") + 1));
            } else {
                int[] subnetMaskArr = parseIpAddress(enteredSubnet);
                cidrPrefix = maskToCidr(subnetMaskArr);
            }

            // Número de subredes requeridas
            int subnetsCount = Integer.parseInt(enteredSubnetCount);

            // Validar que hay suficientes bits para las subredes
            int availableBits = 32 - cidrPrefix;
            int requiredBits = (int) Math.ceil(Math.log(subnetsCount) / Math.log(2));

            if (requiredBits > availableBits) {
                Toast.makeText(this, "No hay suficientes bits disponibles para " + subnetsCount + " subredes. Máximo: " + (int) Math.pow(2, availableBits), Toast.LENGTH_LONG).show();
                return;
            }

            // Calcular dirección de red
            networkBaseAddress = calculateNetworkAddress(ipAddress, cidrPrefix);
            baseCidr = cidrPrefix;

            // Mostrar resultados
            resultContainer.setVisibility(View.VISIBLE);

            // Mostrar detalles ingresados
            tvEnteredDetails.setVisibility(View.VISIBLE);
            tvEnteredDetails.setText("IP: " + enteredIp + " | Máscara: " + enteredSubnet + " | Subredes: " + enteredSubnetCount);

            // Generar hosts requeridos para este ejemplo (se simula la entrada del usuario)
            hostsRequired = new int[subnetsCount];
            for (int i = 0; i < subnetsCount; i++) {
                // Los valores podrían ser ingresados por el usuario en un diálogo
                hostsRequired[i] = (i + 1) * 10; // Por ejemplo: 10, 20, 30, etc.
            }

            // Mostrar hosts por subred en la primera tabla (ordenados de menor a mayor)
            displayHostsPerSubnet(hostsRequired);

            // Mostrar el botón para ver detalles y ocultar la segunda tabla
            btnShowDetails.setVisibility(View.VISIBLE);
            tableSubnets.setVisibility(View.GONE);
            tvSubnetsDetailTitle.setVisibility(View.GONE);

            // Limpiar los campos de entrada después del cálculo
            etIpAddress.setText("");
            etSubnetMask.setText("");
            etSubnetsCount.setText("");

        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    private void showSubnetDetails() {
        if (networkBaseAddress != null && hostsRequired != null) {
            // Calcular VLSM con los hosts almacenados anteriormente
            List<SubnetInfo> subnets = calculateVLSMSubnets(networkBaseAddress, baseCidr, hostsRequired);

            // Mostrar detalles de subredes en la segunda tabla
            displaySubnets(subnets);

            // Mostrar la segunda tabla y su título
            tableSubnets.setVisibility(View.VISIBLE);
            tvSubnetsDetailTitle.setVisibility(View.VISIBLE);
            tvSubnetsDetailTitle.setText("Detalle VLSM");
        }
    }

    // Método mejorado para crear una fila con mejor formato y espaciado
    private TableRow createTableRow(boolean alternateBackground) {
        TableRow row = new TableRow(this);

        // Configuración mejorada de la fila para mejor espaciado
        row.setPadding(8, 16, 8, 16);
        TableRow.LayoutParams layoutParams = new TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT
        );
        layoutParams.setMargins(0, 10, 0, 10);
        row.setLayoutParams(layoutParams);

        // Alternar colores de fondo para mejor legibilidad
        if (alternateBackground) {
            row.setBackgroundColor(Color.parseColor("#f0f0f0"));
        } else {
            row.setBackgroundColor(Color.parseColor("#ffffff"));
        }

        return row;
    }

    // Método mejorado para crear una celda con mejor formato
    private TextView createTableCell(String text) {
        TextView textView = new TextView(this);
        TableRow.LayoutParams params = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f);
        textView.setLayoutParams(params);
        textView.setPadding(16, 16, 16, 16);
        textView.setGravity(Gravity.CENTER);
        textView.setText(text);
        textView.setTextColor(Color.parseColor("#333333"));
        textView.setTextSize(14f);

        // Agregar un borde sutile a la celda
        GradientDrawable shape = new GradientDrawable();
        shape.setStroke(1, Color.parseColor("#dddddd"));
        shape.setCornerRadius(2f);
        textView.setBackground(shape);

        return textView;
    }

    // Método mejorado para crear una celda de encabezado
    private TextView createHeaderCell(String text) {
        TextView headerView = createTableCell(text);
        headerView.setTextColor(Color.parseColor("#000000"));
        headerView.setTextSize(16f);
        headerView.setTypeface(null, Typeface.BOLD);
        return headerView;
    }

    private void displayHostsPerSubnet(int[] hostsRequired) {
        // Limpiar la tabla existente, manteniendo la fila de encabezado
        int count = tableHostsPerSubnet.getChildCount();
        if (count > 1) {
            tableHostsPerSubnet.removeViews(1, count - 1);
        }

        // Crear una lista ordenable de pares (índice, valor)
        List<HostEntry> hostEntries = new ArrayList<>();
        for (int i = 0; i < hostsRequired.length; i++) {
            hostEntries.add(new HostEntry(i + 1, hostsRequired[i]));
        }

        // Ordenar la lista de menor a mayor por número de hosts
        Collections.sort(hostEntries, new Comparator<HostEntry>() {
            @Override
            public int compare(HostEntry o1, HostEntry o2) {
                return Integer.compare(o1.hostCount, o2.hostCount);
            }
        });

        // Agregar filas para cada subred con formato mejorado
        boolean alternateBackground = true;
        for (int i = 0; i < hostEntries.size(); i++) {
            HostEntry entry = hostEntries.get(i);

            // Crear fila con mejor formato
            TableRow row = createTableRow(alternateBackground);
            alternateBackground = !alternateBackground;

            // Agregar celdas con mejor formato
            row.addView(createTableCell("Subred " + entry.subnetNumber));
            row.addView(createTableCell(String.valueOf(entry.hostCount)));

            tableHostsPerSubnet.addView(row);
        }
    }

    private class HostEntry {
        int subnetNumber;
        int hostCount;

        public HostEntry(int subnetNumber, int hostCount) {
            this.subnetNumber = subnetNumber;
            this.hostCount = hostCount;
        }
    }

    private int[] parseIpAddress(String ipStr) {
        String[] parts = ipStr.split("\\.");
        if (parts.length != 4) {
            throw new IllegalArgumentException("Formato de IP inválido");
        }

        int[] ip = new int[4];
        for (int i = 0; i < 4; i++) {
            ip[i] = Integer.parseInt(parts[i]);
            if (ip[i] < 0 || ip[i] > 255) {
                throw new IllegalArgumentException("Octeto de IP fuera de rango: " + ip[i]);
            }
        }
        return ip;
    }

    private int maskToCidr(int[] mask) {
        StringBuilder binary = new StringBuilder();
        for (int octet : mask) {
            String binOctet = Integer.toBinaryString(octet);
            // Rellenar con ceros a la izquierda si es necesario
            while (binOctet.length() < 8) {
                binOctet = "0" + binOctet;
            }
            binary.append(binOctet);
        }

        String binaryStr = binary.toString();
        int count = 0;
        for (int i = 0; i < binaryStr.length(); i++) {
            if (binaryStr.charAt(i) == '1') {
                count++;
            } else {
                break;
            }
        }
        return count;
    }

    private int[] cidrToMask(int cidr) {
        int[] mask = new int[4];
        for (int i = 0; i < 4; i++) {
            if (cidr >= 8) {
                mask[i] = 255;
                cidr -= 8;
            } else if (cidr > 0) {
                mask[i] = 256 - (1 << (8 - cidr));
                cidr = 0;
            } else {
                mask[i] = 0;
            }
        }
        return mask;
    }

    private int[] calculateNetworkAddress(int[] ip, int cidr) {
        int[] mask = cidrToMask(cidr);
        int[] network = new int[4];
        for (int i = 0; i < 4; i++) {
            network[i] = ip[i] & mask[i];
        }
        return network;
    }

    private int[] calculateWildcardMask(int[] subnetMask) {
        int[] wildcardMask = new int[4];
        for (int i = 0; i < 4; i++) {
            wildcardMask[i] = 255 - subnetMask[i];
        }
        return wildcardMask;
    }

    private String ipAddressToString(int[] ip) {
        return ip[0] + "." + ip[1] + "." + ip[2] + "." + ip[3];
    }

    private String ipAddressToBinary(int[] ip) {
        StringBuilder result = new StringBuilder();
        for (int octet : ip) {
            String binary = Integer.toBinaryString(octet);
            while (binary.length() < 8) {
                binary = "0" + binary;
            }
            result.append(binary).append(".");
        }
        // Eliminar el último punto
        if (result.length() > 0) {
            result.setLength(result.length() - 1);
        }
        return result.toString();
    }

    private class SubnetInfo {
        int[] networkAddress;
        int[] firstUsableHost;
        int[] lastUsableHost;
        int[] broadcastAddress;
        int cidr;
        int numHosts;
        int subnetNumber;
        int originalHostCount; // Guardar el número original de hosts solicitados

        public SubnetInfo(int[] networkAddress, int cidr, int subnetNumber, int originalHostCount) {
            this.networkAddress = networkAddress;
            this.cidr = cidr;
            this.subnetNumber = subnetNumber;
            this.originalHostCount = originalHostCount;

            // Calcular hosts disponibles
            this.numHosts = (int) Math.pow(2, 32 - cidr) - 2;
            if (this.numHosts < 0) this.numHosts = 0;

            // Calcular primera dirección de host utilizable
            this.firstUsableHost = networkAddress.clone();
            if (this.numHosts > 0) {
                this.firstUsableHost[3]++;
            } else {
                this.firstUsableHost = networkAddress.clone();
            }

            // Calcular dirección de broadcast
            this.broadcastAddress = calculateBroadcastAddress(networkAddress, cidr);

            // Calcular última dirección de host utilizable
            this.lastUsableHost = broadcastAddress.clone();
            if (this.numHosts > 0) {
                this.lastUsableHost[3]--;
            } else {
                this.lastUsableHost = broadcastAddress.clone();
            }
        }
    }

    private int[] calculateBroadcastAddress(int[] networkAddress, int cidr) {
        int[] wildcardMask = calculateWildcardMask(cidrToMask(cidr));
        int[] broadcast = new int[4];
        for (int i = 0; i < 4; i++) {
            broadcast[i] = networkAddress[i] | wildcardMask[i];
        }
        return broadcast;
    }

    private List<SubnetInfo> calculateVLSMSubnets(int[] networkBaseAddress, int baseCidr, int[] hostsRequired) {
        // Crear lista de requerimientos de hosts y ordenarla de mayor a menor para asignación eficiente
        List<HostRequirement> requirements = new ArrayList<>();
        for (int i = 0; i < hostsRequired.length; i++) {
            requirements.add(new HostRequirement(i + 1, hostsRequired[i]));
        }

        // Ordenar requisitos de mayor a menor para la asignación óptima de subredes
        Collections.sort(requirements, new Comparator<HostRequirement>() {
            @Override
            public int compare(HostRequirement o1, HostRequirement o2) {
                return Integer.compare(o2.hosts, o1.hosts);
            }
        });

        // Lista de subredes resultantes
        List<SubnetInfo> subnets = new ArrayList<>();

        // Dirección de red actual para asignar
        int[] currentNetwork = networkBaseAddress.clone();

        // Para cada requisito, calcular la subred
        for (HostRequirement req : requirements) {
            // Calcular los bits necesarios para los hosts
            int hostBits = (int) Math.ceil(Math.log(req.hosts + 2) / Math.log(2));
            int subnetCidr = 32 - hostBits;

            // Asegurarse de que la subred sea al menos tan grande como la red base
            if (subnetCidr < baseCidr) {
                subnetCidr = baseCidr;
            }

            // Crear información de subred (pasando el número original de hosts)
            SubnetInfo subnet = new SubnetInfo(currentNetwork.clone(), subnetCidr, req.subnetNumber, req.hosts);
            subnets.add(subnet);

            // Calcular la siguiente dirección de red
            currentNetwork = incrementIpAddress(subnet.broadcastAddress);
        }

        return subnets;
    }

    private int[] incrementIpAddress(int[] ip) {
        int[] newIp = ip.clone();
        newIp[3]++;

        // Manejar carry
        for (int i = 3; i > 0; i--) {
            if (newIp[i] > 255) {
                newIp[i] = 0;
                newIp[i-1]++;
            }
        }

        return newIp;
    }

    private class HostRequirement {
        int subnetNumber;
        int hosts;

        public HostRequirement(int subnetNumber, int hosts) {
            this.subnetNumber = subnetNumber;
            this.hosts = hosts;
        }
    }

    private void displaySubnets(List<SubnetInfo> subnets) {
        // Limpiar la tabla existente completamente
        tableSubnets.removeAllViews();

        // Crear una nueva lista para aplicar el ordenamiento
        List<SubnetInfo> sortedSubnets = new ArrayList<>(subnets);

        // Ordenar las subredes por dirección de red (ordenamiento natural de IPs)
        Collections.sort(sortedSubnets, new Comparator<SubnetInfo>() {
            @Override
            public int compare(SubnetInfo o1, SubnetInfo o2) {
                // Comparar cada octeto de la dirección IP
                for (int i = 0; i < 4; i++) {
                    if (o1.networkAddress[i] != o2.networkAddress[i]) {
                        return Integer.compare(o1.networkAddress[i], o2.networkAddress[i]);
                    }
                }
                return 0; // IPs iguales (no debería ocurrir)
            }
        });

        // Crear y agregar una fila de encabezado mejorada (única)
        TableRow headerRow = createTableRow(true);
        headerRow.setBackgroundColor(Color.parseColor("#f2e8dc")); // Cambio a color beige

        // Agregar celdas de encabezado mejoradas
        headerRow.addView(createHeaderCell("Nombre"));
        headerRow.addView(createHeaderCell("Host"));
        headerRow.addView(createHeaderCell("IP de Red"));
        headerRow.addView(createHeaderCell("Última IP"));
        headerRow.addView(createHeaderCell("Broadcast"));

        tableSubnets.addView(headerRow);

        // Agregar filas para cada subred con formato mejorado
        boolean alternateBackground = false;
        for (int i = 0; i < sortedSubnets.size(); i++) {
            SubnetInfo subnet = sortedSubnets.get(i);

            // Crear fila con mejor formato
            TableRow row = createTableRow(alternateBackground);
            alternateBackground = !alternateBackground;

            // Agregar celdas con mejor formato
            row.addView(createTableCell("Subred " + subnet.subnetNumber));
            row.addView(createTableCell(String.valueOf(subnet.originalHostCount)));
            row.addView(createTableCell(ipAddressToString(subnet.networkAddress)));
            row.addView(createTableCell(ipAddressToString(subnet.lastUsableHost)));
            row.addView(createTableCell(ipAddressToString(subnet.broadcastAddress)));

            tableSubnets.addView(row);
        }
    }
}
